import { Component } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Login from './components/Login';
import Home from './components/Home';
import User from './components/User';
import Post from './components/Post';
import DashboardContext from './context/DashboardContext';

import './App.css';

const postsList = {
  total_posts: 16,
  total_value: 24700,
  posts: [
    {
      post_id: 1,
      post_caption: 'Beautiful sunset at the beach!',
      media_url: 'https://example.com/media/sunset.jpg',
      post_published_time: '2024-08-01 18:30:00',
    },
    {
      post_id: 2,
      post_caption: 'Delicious homemade pizza.',
      media_url: 'https://example.com/media/pizza.jpg',
      post_published_time: '2024-08-02 12:45:00',
    },
    {
      post_id: 3,
      post_caption: 'Hiking adventure in the mountains.',
      media_url: 'https://example.com/media/hiking.jpg',
      post_published_time: '2024-08-03 08:15:00 ',
    },
    {
      post_id: 4,
      post_caption: 'My cat enjoying a lazy afternoon.',
      media_url: 'https://example.com/media/cat.jpg',
      post_published_time: '2024-08-04 14:20:00',
    },
    {
      post_id: 5,
      post_caption: 'Exploring the city at night.',
      media_url: 'https://example.com/media/city.jpg',
      post_published_time: '2024-08-05 21:30:00',
    },
    {
      post_id: 6,
      post_caption: 'Fresh flowers from the garden.',
      media_url: 'https://example.com/media/flowers.jpg',
      post_published_time: '2024-08-06 09:40:00',
    },
    {
      post_id: 7,
      post_caption: 'Coffee break with a view.',
      media_url: 'https://example.com/media/coffee.jpg',
      post_published_time: '2024-08-07 10:50:00',
    },
    {
      post_id: 8,
      post_caption: 'Reading a book on a rainy day.',
      media_url: 'https://example.com/media/book.jpg',
      post_published_time: '2024-08-08 16:35:00',
    },
    {
      post_id: 9,
      post_caption: 'Street art in downtown.',
      media_url: 'https://example.com/media/streetart.jpg',
      post_published_time: '2024-08-09 11:00:00',
    },
    {
      post_id: 10,
      post_caption: 'Enjoying a day at the park.',
      media_url: 'https://example.com/media/park.jpg',
      post_published_time: '2024-08-10 13:10:00',
    },
    {
      post_id: 11,
      post_caption: 'Homemade dessert for the weekend.',
      media_url: 'https://example.com/media/dessert.jpg',
      post_published_time: '2024-08-11 19:25:00',
    },
    {
      post_id: 12,
      post_caption: 'Sunrise over the mountains.',
      media_url: 'https://example.com/media/sunrise.jpg',
      post_published_time: '2024-08-12 06:50:00',
    },
    {
      post_id: 13,
      post_caption: 'Chilling by the pool.',
      media_url: 'https://example.com/media/pool.jpg',
      post_published_time: '2024-08-13 15:45:00',
    },
    {
      post_id: 14,
      post_caption: 'Cozy evening by the fireplace.',
      media_url: 'https://example.com/media/fireplace.jpg',
      post_published_time: '2024-08-14 20:15:00',
    },
    {
      post_id: 15,
      post_caption: 'A walk in the forest.',
      media_url: 'https://example.com/media/forest.jpg',
      post_published_time: '2024-08-15 07:05:00',
    },
    {
      post_id: 16,
      post_caption: 'Sunset in the desert.',
      media_url: 'https://example.com/media/desert.jpg',
      post_published_time: '2024-08-16 18:20:00',
    },
  ],
};

const usersList = {
  total_users: 16,
  total_value: 24700,
  users: [
    {
      user_id: 1,
      username: 'johndoe',
      name: 'John Doe',
      email: 'johndoe@example.com',
      last_active_time: '2024-08-10 14:30:00',
    },
    {
      user_id: 2,
      username: 'janesmith',
      name: 'Jane Smith',
      email: 'janesmith@example.com',
      last_active_time: '2024-08-02 09:45:00',
    },
    {
      user_id: 3,
      username: 'michaeljohnson',
      name: 'Michael Johnson',
      email: 'michaeljohnson@example.com',
      last_active_time: '2024-08-10 11:15:00',
    },
    {
      user_id: 4,
      username: 'emilydavis',
      name: 'Emily Davis',
      email: 'emilydavis@example.com',
      last_active_time: '2024-08-04 10:20:00',
    },
    {
      user_id: 5,
      username: 'davidsmith',
      name: 'David Smith',
      email: 'davidsmith@example.com',
      last_active_time: '2024-08-05 08:30:00',
    },
    {
      user_id: 6,
      username: 'laurajones',
      name: 'Laura Jones',
      email: 'laurajones@example.com',
      last_active_time: '2024-08-06 15:40:00',
    },
    {
      user_id: 7,
      username: 'chriswilson',
      name: 'Chris Wilson',
      email: 'chriswilson@example.com',
      last_active_time: '2024-08-07 13:50:00',
    },
    {
      user_id: 8,
      username: 'patriciaharris',
      name: 'Patricia Harris',
      email: 'patriciaharris@example.com',
      last_active_time: '2024-08-08 12:35:00',
    },
    {
      user_id: 9,
      username: 'robertbrown',
      name: 'Robert Brown',
      email: 'robertbrown@example.com',
      last_active_time: '2024-08-09 14:00:00 ',
    },
    {
      user_id: 10,
      username: 'lindawalker',
      name: 'Linda Walker',
      email: 'lindawalker@example.com',
      last_active_time: '2024-08-10 09:10:00',
    },
    {
      user_id: 11,
      username: 'jamesmoore',
      name: 'James Moore',
      email: 'jamesmoore@example.com',
      last_active_time: '2024-08-09 11:25:00',
    },
    {
      user_id: 12,
      username: 'mariasanchez',
      name: 'Maria Sanchez',
      email: 'mariasanchez@example.com',
      last_active_time: '2024-08-10 11:50:00 ',
    },
    {
      user_id: 13,
      username: 'marklewis',
      name: 'Mark Lewis',
      email: 'marklewis@example.com',
      last_active_time: '2024-08-09 08:45:00',
    },
    {
      user_id: 14,
      username: 'barbaraclark',
      name: 'Barbara Clark',
      email: 'barbaraclark@example.com',
      last_active_time: '2024-08-09 14:15:00',
    },
    {
      user_id: 15,
      username: 'thomasyoung',
      name: 'Thomas Young',
      email: 'thomasyoung@example.com',
      last_active_time: '2024-08-10 10:05:00',
    },
    {
      user_id: 16,
      username: 'elisewright',
      name: 'Elise Wright',
      email: 'elisewright@example.com',
      last_active_time: '2024-08-10 12:20:00',
    },
  ],
};

class App extends Component {
  state = {
    usersList: usersList,
    postsList: postsList,
    lastActiveUsersList: [],
    lastActivePostsList: [],
  };

  componentDidMount() {
    this.lastActivePosts();
    this.lastActiveUsers();
  }

  lastActiveUsers = () => {
    const lastActiveUsers24 = usersList.users.filter((e) => {
      let time = new Date();
      let last = e.last_active_time;
      console.log(time - new Date(last).getTime());
      if (time - new Date(last).getTime() < 86400000) {
        return e;
      }
    });
    this.setState({ lastActiveUsersList: lastActiveUsers24 });
  };

  lastActivePosts = () => {
    const lastActivePosts24 = postsList.posts.filter((e) => {
      let time = new Date();
      let last = e.post_published_time;
      console.log(time - new Date(last).getTime());
      if (time - new Date(last).getTime() < 86400000) {
        return e;
      }
      return;
    });
    this.setState({ lastActivePostsList: lastActivePosts24 });
  };

  render() {
    const { usersList, postsList, lastActiveUsersList, lastActivePostsList } =
      this.state;
    return (
      <DashboardContext.Provider
        value={{
          usersList,
          postsList,
          lastActivePostsList,
          lastActiveUsersList,
          lastActiveUsers: this.lastActiveUsers,
          lastActivePosts: this.lastActivePosts,
        }}
      >
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Login />} />
            <Route path="/home" element={<Home />} />
            <Route path="/user" element={<User />} />
            <Route path="/post" element={<Post />} />
          </Routes>
        </BrowserRouter>
      </DashboardContext.Provider>
    );
  }
}

export default App;
