import React from 'react';
import { useEffect, useState } from 'react';
import { IoIosCloseCircle } from 'react-icons/io';
import {
  MdDelete,
  MdHideSource,
  MdNavigateBefore,
  MdNavigateNext,
} from 'react-icons/md';
import Popup from 'reactjs-popup';
import 'reactjs-popup/dist/index.css';

import DashbosrdContext from '../../context/DashboardContext';

import Sidebar from '../Sidebar';

const Post = () => {
  const value = React.useContext(DashbosrdContext);
  const { postsList, lastActivePostsList } = value;
  const totalRows = 8;
  const initialData = postsList.posts.slice(0, totalRows);
  const totalPosts = postsList.total_posts;
  const total24Posts = lastActivePostsList.length;
  const [curPage, setCurPage] = useState(1);
  const [dataDisplay, setDataDisplay] = useState(initialData);

  const setCurPageBefore = () => {
    if (curPage !== 1) {
      setCurPage((prev) => prev - 1);
    }
  };

  const setCurPageNext = () => {
    if (curPage !== Math.ceil(totalPosts / totalRows)) {
      setCurPage((prev) => prev + 1);
    }
  };

  useEffect(() => {
    const start = (curPage - 1) * totalRows;
    const end = curPage * totalRows;
    setDataDisplay(postsList.posts.slice(start, end));
  }, [curPage]);

  return (
    <div className="home-con">
      <div className="sidebar-con">
        <Sidebar />
      </div>
      <div className="content-con">
        {/*
      <Header />
      */}
        <h1 className="heading">Posts Dashboard</h1>
        <div className="home-kpis">
          <div>
            <h1>Total Posts</h1>
            <p>{totalPosts}</p>
          </div>
          <div>
            <h1>Posts of last 24hrs</h1>
            <p>{total24Posts}</p>
          </div>
        </div>
        <div>
          <table>
            <tr>
              <th>Post id</th>
              <th>Post caption</th>
              <th>Media url</th>
              <th>Published time</th>
              <th>actions</th>
            </tr>

            {dataDisplay.map((e) => (
              <tr>
                <td>{e.post_id}</td>
                <td>{e.post_caption}</td>
                <td>{e.media_url}</td>
                <td>{e.post_published_time}</td>
                <td className="btn-con">
                  <Popup
                    modal
                    trigger={
                      <button type="button">
                        <MdDelete />
                      </button>
                    }
                  >
                    {(close) => (
                      <div className="popup-con">
                        <button type="button" onClick={() => close()}>
                          <IoIosCloseCircle />
                        </button>
                        <p>Do you really need to delete this post?</p>
                      </div>
                    )}
                  </Popup>
                  <Popup
                    modal
                    trigger={
                      <button type="button" onClick={''}>
                        <MdHideSource />
                      </button>
                    }
                  >
                    {(close) => (
                      <div className="popup-con">
                        <button type="button" onClick={() => close()}>
                          <IoIosCloseCircle />
                        </button>
                        <p>Do you really need to hide this post?</p>
                      </div>
                    )}
                  </Popup>
                </td>
              </tr>
            ))}
          </table>
          <div className="btn-con-bottom">
            <button type="button" onClick={setCurPageBefore}>
              <MdNavigateBefore />
            </button>
            <button type="button" onClick={setCurPageNext}>
              <MdNavigateNext />
            </button>
          </div>
        </div>
        {/*<Footer />*/}
      </div>
    </div>
  );
};

export default Post;
