import { Link } from 'react-router-dom';
import './index.css';

const Sidebar = () => (
  <div>
    <h1>.Social Dashboard</h1>
    <div className="nav-con">
      <p>
        <Link to="/">Home</Link>
      </p>
      <p>
        <Link to="/user">User Page</Link>
      </p>
      <p>
        <Link to="/post">Post Page</Link>
      </p>
    </div>
  </div>
);

export default Sidebar;
