import React from 'react';
import { useEffect, useState } from 'react';
import { CiEdit } from 'react-icons/ci';
import { FaBan } from 'react-icons/fa';
import { IoIosCloseCircle } from 'react-icons/io';
import { MdNavigateBefore, MdNavigateNext } from 'react-icons/md';
import Popup from 'reactjs-popup';
import 'reactjs-popup/dist/index.css';
import DashbosrdContext from '../../context/DashboardContext';
import Sidebar from '../Sidebar';

import './index.css';

const User = () => {
  const value = React.useContext(DashbosrdContext);
  const { usersList, lastActiveUsersList } = value;

  const totalRows = 8;
  const initialData = usersList.users.slice(0, totalRows);
  const totalUsers = usersList.total_users;
  const total24Users = lastActiveUsersList.length;
  const [curPage, setCurPage] = useState(1);
  const [dataDisplay, setDataDisplay] = useState(initialData);

  const setCurPageBefore = () => {
    if (curPage !== 1) {
      setCurPage((prev) => prev - 1);
    }
  };

  const setCurPageNext = () => {
    if (curPage !== Math.ceil(totalUsers / totalRows)) {
      setCurPage((prev) => prev + 1);
    }
  };

  useEffect(() => {
    const start = (curPage - 1) * totalRows;
    const end = curPage * totalRows;
    setDataDisplay(usersList.users.slice(start, end));
  }, [curPage]);

  return (
    <div className="home-con">
      <div className="sidebar-con">
        <Sidebar />
      </div>
      <div className="content-con">
        {/*
      <Header />
      */}
        <h1 className="heading">Users Dashboard</h1>
        <div className="home-kpis">
          <div>
            <h1>Total Users</h1>
            <p>{totalUsers}</p>
          </div>
          <div>
            <h1>Users active for last 24hrs</h1>
            <p>{total24Users}</p>
          </div>
        </div>
        <div>
          <table>
            <tr>
              <th>user_id</th>
              <th>username</th>
              <th>name</th>
              <th>email</th>
              <th>actions</th>
            </tr>

            {dataDisplay.map((e) => (
              <tr>
                <td>{e.user_id}</td>
                <td>{e.username}</td>
                <td>{e.name}</td>
                <td>{e.email}</td>
                <td className="btn-con">
                  <Popup
                    modal
                    trigger={
                      <button type="button">
                        <CiEdit />
                      </button>
                    }
                  >
                    {(close) => (
                      <div className="popup-con">
                        <button type="button" onClick={() => close()}>
                          <IoIosCloseCircle />
                        </button>
                        <p>Do you really need to edit?</p>
                      </div>
                    )}
                  </Popup>
                  <Popup
                    modal
                    trigger={
                      <button type="button" onClick={''}>
                        <FaBan />
                      </button>
                    }
                  >
                    {(close) => (
                      <div className="popup-con">
                        <button type="button" onClick={() => close()}>
                          <IoIosCloseCircle />
                        </button>
                        <p>Do you really need to ban this user?</p>
                      </div>
                    )}
                  </Popup>
                </td>
              </tr>
            ))}
          </table>
          <div className="btn-con-bottom">
            <button type="button" onClick={setCurPageBefore}>
              <MdNavigateBefore />
            </button>
            <button type="button" onClick={setCurPageNext}>
              <MdNavigateNext />
            </button>
          </div>
        </div>
        {/*<Footer />*/}
      </div>
    </div>
  );
};

export default User;
