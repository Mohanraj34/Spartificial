import React from 'react';
import Sidebar from '../Sidebar';
import DashbosrdContext from '../../context/DashboardContext';
import './index.css';

const Home = () => {
  const value = React.useContext(DashbosrdContext);
  const { postsList, usersList, lastActivePostsList, lastActiveUsersList } =
    value;
  const totalUsers = usersList.total_users;
  const totalPosts = postsList.total_posts;
  const total24Users = lastActiveUsersList.length;
  const total24Posts = lastActivePostsList.length;

  return (
    <div className="home-con">
      <div className="sidebar-con">
        <Sidebar />
      </div>
      <div className="content-con">
        {/*
      <Header />
      */}
        <h1 className="heading">Home Dashboard</h1>
        <div className="home-kpis">
          <div>
            <h1>Total Users</h1>
            <p>{totalUsers}</p>
          </div>
          <div>
            <h1>Total Posts</h1>
            <p>{totalPosts}</p>
          </div>
          <div>
            <h1>Users active for last 24hrs</h1>
            <p>{total24Users}</p>
          </div>
          <div>
            <h1>Posts of last 24hrs</h1>
            <p>{total24Posts}</p>
          </div>
        </div>
        {/*<Footer />*/}
      </div>
    </div>
  );
};

export default Home;
