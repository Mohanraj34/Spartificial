import React from 'react';

const DashbosrdContext = React.createContext({
  usersList: [],
  postsList: [],
  lastActiveUsers: () => {},
  lastActivePosts: () => {},
  lastActiveUsersList: [],
  lastActivePostsList: [],
});

export default DashbosrdContext;
